let list = ""

fetch("data.json")
.then(response => response.json())
.then(data => {
    data.map(item => {
        list = list + (
            `<figure>
                <img src=${item.img} alt=${item.img}/>
                <figcaption>
                    <span>Name Product Demo</span>
                    <span>${item.price}</span>
                </figcaption>
                <button type="button" onclick="writeDesc('${item.desc}')">ADD TO CART</button>
            </figure>`
        )
    })
    document.querySelector("main").innerHTML = list
})
.catch(error => console.log("Błąd: ", error));

const writeDesc = desc =>{
    console.log(desc)
}